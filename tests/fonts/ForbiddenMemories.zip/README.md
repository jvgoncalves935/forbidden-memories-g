# Forbidden Memories Font

- Author: Master Exploder (Converting Minds)
- Created based on the "Yu-Gi-Oh: Forbidden Memories" gamerip font chart made by "borderoflife".
- Gamerip Font Chart: https://www.spriters-resource.com/playstation/ygofm/sheet/144403/
- Original Font: Unknown.
- Copyright (?): Konami Entertaiment Japan.
- DO NOT use this font for commercial use, only for free and non-commercial purposes.

- GitHub: https://github.com/jvgoncalves935/forbidden-memories-font
